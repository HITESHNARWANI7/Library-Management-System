-- MariaDB dump 10.19  Distrib 10.4.22-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	10.4.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books_data`
--

DROP TABLE IF EXISTS `books_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books_data` (
  `Book_Id` int(11) NOT NULL,
  `Book_Name` varchar(100) DEFAULT NULL,
  `Book_Author` varchar(100) DEFAULT NULL,
  `Book_Published_Year` int(11) DEFAULT NULL,
  `Book_Category` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Book_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_data`
--

LOCK TABLES `books_data` WRITE;
/*!40000 ALTER TABLE `books_data` DISABLE KEYS */;
INSERT INTO `books_data` VALUES (1001,'Treasure Island','Robert Louis Stevenson',1883,'Action'),(1002,'Da Vinci Code','Dan Brown',2003,'Action'),(1003,'Catching Fire','Suzanne Collins',2009,'Action'),(1004,'The Great Gatsby','F. Scott Fitzgerald',1925,'Noval'),(1005,'Jane Eyre','Charlotte Bronte',1990,'Noval'),(1006,'Ulysses','James Roy',1922,'Noval'),(1007,'Lord Of The Flies','William Golding',1954,'Literature'),(1008,'How Children Fail','John Holt',1982,'Education'),(1009,'Make It Stick','Dainel',1922,'Education'),(1010,'Great People','Joe Root',1929,'Noval'),(1011,'Phy','Hc Verma',1989,'Physics'),(1012,'Vedic Mathematics','Bharati Krishna Tirtha',2004,'Mathematics'),(1013,'Never Give Up','Joe Root',1960,'Noval'),(1014,'Phy Part Second','Hc Verma',1989,'Physics'),(1015,'Jee Maths','Bharati Krishna Tirtha',2004,'Mathematics'),(1016,'R For Data Science','Garrett Grolemund And Hadley Wickham',2016,'Programming'),(1017,'Deep Learning With Python','Francois Chollet',2018,'Programming'),(1018,'Data Science For Business','Maxwell',1990,'Data Science'),(1019,'Brave New World','Aldous Huxley',1932,'Science Fiction'),(2020,'Lolita','Comedy',1932,'Science Fiction'),(2025,'Objective Maths','Rd Sharma',1999,'Mathematics');
/*!40000 ALTER TABLE `books_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `librarian_data`
--

DROP TABLE IF EXISTS `librarian_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `librarian_data` (
  `L_Id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `librarian_data`
--

LOCK TABLES `librarian_data` WRITE;
/*!40000 ALTER TABLE `librarian_data` DISABLE KEYS */;
INSERT INTO `librarian_data` VALUES (1,'Om Prakash','Omprakash!!321','Jaipur'),(2,'Kavi Singh','Kavi!!321','Jodhpur'),(3,'Priyanka khatri','Priyanka!!321','Jaipur');
/*!40000 ALTER TABLE `librarian_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_book_data`
--

DROP TABLE IF EXISTS `user_book_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_book_data` (
  `user_id` int(11) NOT NULL,
  `Student_Name` varchar(100) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `book_name` varchar(100) DEFAULT NULL,
  `submission_date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_book_data`
--

LOCK TABLES `user_book_data` WRITE;
/*!40000 ALTER TABLE `user_book_data` DISABLE KEYS */;
INSERT INTO `user_book_data` VALUES (3,'Aarti',1016,'R For Data Science','2022-02-12'),(4,'Navratan Jat',1019,'Brave New World','2022-01-15'),(18,'Navratan',1015,'Jee Maths','2022-01-15'),(2,'Gulshan Bundel',1004,'The Great Gatsby','2022-02-18'),(2,'Gulshan Bundel',1014,'Phy Part Second','2022-02-22'),(2,'Gulshan Bundel',1010,'Great People','2022-02-22');
/*!40000 ALTER TABLE `user_book_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(100) DEFAULT NULL,
  `User_age` int(11) DEFAULT NULL,
  `User_email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2030 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
INSERT INTO `user_data` VALUES (1,'Hitesh Narwani',21,'hiteshnarwani111@gmail.com','Hitesh!!321'),(2,'Gulshan Bundel',25,'gulshanbundel123@gmail.com','Gulshan!!321'),(3,'Aarti',20,'aarti12@gmail.com','Aarti!!321'),(4,'Navratan Jat',22,'navratanjat8875@gmail.com','Navratan!!321'),(5,'Ajay Sharma',24,'ajaypandit12@gmail.com','Ajay!!321'),(6,'Atul Sharma',24,'atulsharma111@gmail.com','Atul!!321'),(7,'Somendra Soni',20,'somendrasoni308@gmail.com','Somendra!!321'),(8,'Mukul Soni',22,'mukulsoni9090@gmail.com','Mukul!!321'),(9,'Abhishek Sharma',23,'abhisheksharma1234@gmail.com','Abhishek!!321'),(10,'Ajay Singh',23,'ajaysingh34@gmail.com','Ajay!!321'),(11,'Vicky Gangster',23,'vickygang007@gmail.com','Vicky!!321'),(12,'Jatin Badlani',22,'jatinbad6@gmail.com','Jatin!!321'),(13,'Chirag',21,'chira123@gmail.com','Chirag!!321'),(14,'Chinmay',29,'chinmaypak12@gmail.com','Chinmay!!321'),(15,'Ravi Arora',27,'ravi12@gmail.com','Ravi!!321'),(16,'Ankita',22,'ankitajain111@gmail.com','Ankita!!321'),(17,'Amit Jain',25,'amitjain111@gmail.com','Amit!!321'),(18,'Navratan',25,'navratanghantiyala@gmail.com','Navratan!!321'),(35,'Devanshu',21,'devanshu11@gmail.com','Devanshu!!321'),(2026,'Jatin Sharma',23,'jatinsharma@gmail.com','Jatin!!!321'),(2027,'Simran',24,'simrangrover5@gmail.com','Simran!!321'),(2028,'Ajay',21,'hiteshnarwani111@gmail.com','Ajay!!321'),(2029,'chotu',23,'abhi12345xxx@gmail.com','Sharma!!321');
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-05 11:10:59
